package files;
import java.io.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;

public class Strawberry {
    public JFrame frame = new JFrame("STRAWBERRY");
    public JPanel panel = new JPanel();
    JLabel text = new JLabel();
    public JLabel img;
    public int count;
    public final int LUCKY_NUMBER = 15_000;
    public File file = new File("./src/files/data.txt");
    public Random CHOSEN_NUMBER = new Random();
    public int BERRIES_FOR_A_CLICK = 1;
    public int isLucky = -1;
    public Color red = new Color(242, 150, 150);

    public Strawberry(int count) {
        this.count = count;

        if (!(importdata()))
            frame.dispose();
        
        else{
            initElements();
            paintElements();
            setFrameProperties();
            frame.requestFocus();
            JOptionPane.showMessageDialog(null, "Welcome to the Strawberry game. Press strawberry to collect it. Press ESC button to exit game.", "Welcome", JOptionPane.PLAIN_MESSAGE);
            BERRIES_FOR_A_CLICK = isLucky == -1 ? 1 : 5;
        }
    }

    public void setFrameProperties() {
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setUndecorated(true);
        frame.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    var choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit game", JOptionPane.YES_NO_OPTION);
                    if (choice == JOptionPane.YES_OPTION)
                        frame.dispose();
                } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    click();
                }
            }
        });
        frame.setVisible(true);
    }

    public void initElements() {
        if (isLucky == -1)
            img = new JLabel(new ImageIcon("./src/files/strawberry.png"));
        else
            img = new JLabel(new ImageIcon("./src/files/strawberries.png"));
        img.setAlignmentX(Component.CENTER_ALIGNMENT);
        text.setAlignmentX(Component.CENTER_ALIGNMENT);
        img.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                click();
                frame.requestFocus();
                img.setBackground(red);
            }
        });
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(img);
        panel.add(text);
        frame.add(panel);
    }

    public void paintElements() {
        panel.setBackground(red);
        img.setBackground(red);
        img.setBorder(BorderFactory.createLineBorder(red, 5));
        text.setFont(new Font("Arial", Font.PLAIN, 40));
    }

    public void click() {
        count += BERRIES_FOR_A_CLICK;
        text.setText(String.valueOf(count));
        if (!exportdata())
            frame.dispose();
        if (CHOSEN_NUMBER.nextInt(LUCKY_NUMBER+1) == LUCKY_NUMBER && isLucky == -1){
            img.setIcon(new ImageIcon("./src/files/strawberries.png"));
            JOptionPane.showMessageDialog(null, "You got 4 more strawberries.", "Congratulation!", JOptionPane.PLAIN_MESSAGE);
            isLucky = 0;
        }
    }

    public boolean importdata(){
        try{
            var s = new Scanner(file);
            count = s.nextInt();
            isLucky = s.nextInt();
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, "Something went wrong\n" + e, "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    public boolean exportdata(){
        try{
            var p = new PrintWriter(file);
            p.println(count);
            p.print(isLucky);
            p.flush();
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, "Something went wrong:\n" + e, "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    public static void main(String[] str) {
        new Strawberry(0);
    }
}
